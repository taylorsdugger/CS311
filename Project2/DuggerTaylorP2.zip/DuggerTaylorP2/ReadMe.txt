This is done by just me, Taylor Dugger.
