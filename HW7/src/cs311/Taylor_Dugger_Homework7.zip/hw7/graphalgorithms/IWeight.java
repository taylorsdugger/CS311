package cs311.hw7.graphalgorithms;

public interface IWeight
{
    public double getWeight();
}
